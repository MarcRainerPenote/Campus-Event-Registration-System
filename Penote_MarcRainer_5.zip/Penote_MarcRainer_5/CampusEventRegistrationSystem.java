import javax.swing.*;
import java.awt.*;

public class CampusEventRegistrationSystem {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Campus Event Registration System");
        frame.setSize(1300, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));

        JLabel lblName = new JLabel("Participants Name: ");
        JTextField txtName = new JTextField(15);
        JLabel lblAge = new JLabel("Age: ");
        JTextField txtAge = new JTextField(15);

        JLabel lblDepartment = new JLabel("College/Department");
        String[] department = {"Select Your Department", "BSIT", "BTLED", "BFPT"};
        JComboBox<String> cmbdepartment = new JComboBox<>(department);

        JLabel lblEvent = new JLabel("Event Category: ");
        String[] Event = {"Select Event", "Programming Competition", "Web Design Challenge", "Cybersecurity Seminar", "AI and Emerging Technologies", "IT Quiz Bowl"};
        JComboBox<String> cmbEventBox = new JComboBox<>(Event);

        JLabel lblattendance = new JLabel("Attendance Type: ");
        JRadioButton a = new JRadioButton("Student Participant");
        JRadioButton b = new JRadioButton("Student Audience");
        JRadioButton c = new JRadioButton("Faculty/Staff");

        JLabel lblWorkShop = new JLabel("Workshops to Attend: ");
        JCheckBox v1 = new JCheckBox("Java Programming");
        JCheckBox v2 = new JCheckBox("Web Development");
        JCheckBox v3 = new JCheckBox("Cybersecurity");
        JCheckBox v4 = new JCheckBox("Artificial Intelligence");
        JCheckBox v5 = new JCheckBox("Database Management");

        ButtonGroup Attendance = new ButtonGroup();
        Attendance.add(a);
        Attendance.add(b);
        Attendance.add(c);

        JLabel lblSpecialRequest = new JLabel("Special Request: ");
        JTextArea txtSpecialRequest = new JTextArea(5, 30);
        txtSpecialRequest.setLineWrap(true);
        txtSpecialRequest.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(txtSpecialRequest);

        JButton btnRegister = new JButton("Register");
        JButton btnClear = new JButton("Clear");

        frame.add(lblName);
        frame.add(txtName);
        frame.add(lblAge);
        frame.add(txtAge);
        frame.add(lblDepartment);
        frame.add(cmbdepartment);
        frame.add(lblEvent);
        frame.add(cmbEventBox);
        frame.add(lblattendance);
        frame.add(a);
        frame.add(b);
        frame.add(c);
        frame.add(lblWorkShop);
        frame.add(v1);
        frame.add(v2);
        frame.add(v3);
        frame.add(v4);
        frame.add(v5);
        frame.add(lblSpecialRequest);
        frame.add(scrollPane);
        frame.add(btnRegister);
        frame.add(btnClear);

        btnRegister.addActionListener(e -> {
            String name = txtName.getText().trim();
            String ageText = txtAge.getText().trim();

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter Participant Name!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                txtName.requestFocus();
                return;
            }

            if (ageText.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter Age!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                txtAge.requestFocus();
                return;
            }

            int age;
            try {
                age = Integer.parseInt(ageText);
                if (age <= 0) {
                    JOptionPane.showMessageDialog(frame, "Age must be greater than zero!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                    txtAge.requestFocus();
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Age must be a valid whole number!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                txtAge.requestFocus();
                return;
            }

            if (cmbdepartment.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(frame, "Please select a College/Department!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                cmbdepartment.requestFocus();
                return;
            }
            String section = cmbdepartment.getSelectedItem().toString();

            if (cmbEventBox.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(frame, "Please select an Event Category!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                cmbEventBox.requestFocus();
                return;
            }
            String event = cmbEventBox.getSelectedItem().toString();

            String AttendanceStyle;
            if (a.isSelected()) {
                AttendanceStyle = a.getText();
            } else if (b.isSelected()) {
                AttendanceStyle = b.getText();
            } else if (c.isSelected()) {
                AttendanceStyle = c.getText();
            } else {
                JOptionPane.showMessageDialog(frame, "Please select an Attendance Type!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            StringBuilder workshops = new StringBuilder();
            if (v1.isSelected()) workshops.append("Java Programming\n");
            if (v2.isSelected()) workshops.append("Web Development\n");
            if (v3.isSelected()) workshops.append("Cybersecurity\n");
            if (v4.isSelected()) workshops.append("Artificial Intelligence\n");
            if (v5.isSelected()) workshops.append("Database Management\n");
            if (workshops.length() == 0) workshops.append("None\n");

            String specialRequest = txtSpecialRequest.getText().trim();
            if (specialRequest.isEmpty()) {
                specialRequest = "None";
            }

            String summary =
                    "         REGISTRATION SUMMARY           \n\n" +
                    "Participants Name: " + name + "\n" +
                    "Age: " + age + "\n" +
                    "College/Department: " + section + "\n" +
                    "Event Category: " + event + "\n" +
                    "Attendance Type: " + AttendanceStyle + "\n\n" +
                    "Workshops:\n" + workshops +
                    "\nSpecial Request:\n" + specialRequest +
                    "\n==========================================";

            JOptionPane.showMessageDialog(frame, summary, "Registration Successful", JOptionPane.INFORMATION_MESSAGE);
        });

        btnClear.addActionListener(e -> {
            txtName.setText("");
            txtAge.setText("");
            cmbdepartment.setSelectedIndex(0);
            cmbEventBox.setSelectedIndex(0);
            Attendance.clearSelection();
            v1.setSelected(false);
            v2.setSelected(false);
            v3.setSelected(false);
            v4.setSelected(false);
            v5.setSelected(false);
            txtSpecialRequest.setText("");
            txtName.requestFocus();
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
